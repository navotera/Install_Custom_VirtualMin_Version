desc_pl=Wirtualne serwery Virtualmin
